package backpack.android.zamora.mil.backpackapp.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import backpack.android.zamora.mil.backpackapp.R;

public class BackpackActivityDetailFactura extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mochila_detail_factura);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.setTitle("Mi Factura de Mochilas");

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}
