package backpack.android.zamora.mil.backpackapp.entity;

import java.util.ArrayList;

public class BackpackRepository {

    Backpack backpack;

    public static ArrayList<Backpack> imageMovieArrayList= new ArrayList<Backpack>();


    public  BackpackRepository() {
        if(backpack==null){
            backpack=new Backpack();
        }

    }

    public Backpack getBackpack() {
        return backpack;
    }


    public static void initializeData() {
        imageMovieArrayList.removeAll(getImageMovieArrayList());
        imageMovieArrayList.add(
                new Backpack(1, "Elemental Sportwears", "Marca: Nike", 4.0, 45,  "https://www.amazon.com/Sportswear-Hayward-Futura-Backpack-Black-x/dp/B0163G9T1K/ref=sr_1_1?ie=UTF8&qid=1544593997&sr=8-1&keywords=mochilas+para+hombres+nike",
                        "", "N", 2, ""));
        imageMovieArrayList.add(
                new Backpack(2, "Club Team Swoosh", "Marca:Nike", 3.0, 49, "https://www.amazon.com/NIKE-Club-Team-Swoosh-Backpack/dp/B00VOC6JA8/ref=sr_1_2?ie=UTF8&qid=1544615320&sr=8-2&keywords=mochilas+para+hombres+nike",
                        "", "S", 3, ""));
        imageMovieArrayList.add (
                new Backpack(3, "Academi Schoolar", "Marca:Nike", 2.0, 35, "https://www.amazon.com/Academy-Football-School-Backpack-Anthracite/dp/B004HZCV2E/ref=sr_1_3?ie=UTF8&qid=1544615320&sr=8-3&keywords=mochilas+para+hombres+nike",
                        "", "N", 0, ""));
        imageMovieArrayList.add(
                new Backpack(4, "Vapor Power", "Marca:Nike", 2.0, 40, "https://www.amazon.com/Training-Backpack-Blustery-Metallic-Silver/dp/B074MFTMFT/ref=sr_1_4?ie=UTF8&qid=1544615320&sr=8-4&keywords=mochilas+para+hombres+nike",
                        "", "N", 1, ""));
        imageMovieArrayList.add(
                new Backpack( 5, "Team Black", "Marca:Nike", 1.0, 36.50, "https://www.amazon.com/Nike-Swoosh-Backpack-Black-White/dp/B005OTEHUG/ref=sr_1_5?ie=UTF8&qid=1544615320&sr=8-5&keywords=mochilas+para+hombres+nike",
                        "", "N", 0, ""));
        imageMovieArrayList.add(
                new Backpack(6, "Hoops Elite Pro", "Marca:Nike", 4.0, 50, "https://www.amazon.com/Hoops-Elite-Basketball-Backpack-Gunsmoke/dp/B07FFT985T/ref=sr_1_6?ie=UTF8&qid=1544615320&sr=8-6&keywords=mochilas+para+hombres+nike",
                        "", "S", 0, "" ));
        imageMovieArrayList.add(
                new Backpack( 7, "Brazilia", "Marca:Nike", 3.0, 45.50, "https://www.amazon.com/NIKE-Brasilia-Extra-Large-Training-Backpack/dp/B01GWKA0O2/ref=sr_1_7?ie=UTF8&qid=1544615320&sr=8-7&keywords=mochilas+para+hombres+nike",
                        "", "N", 0, ""));
        imageMovieArrayList.add (
                new Backpack(8, "Sport Gold", "Marca:Nike", 3.0, 60,"https://www.amazon.com/Nike-Sport-Backpack-Black-Heather/dp/B0163GMZ7K/ref=sr_1_9?ie=UTF8&qid=1544615320&sr=8-9&keywords=mochilas+para+hombres+nike",
                        "", "N", 0, ""));
        imageMovieArrayList.add(
                new Backpack(9, "Hustle", "Marca:Harmour", 3.0, 75, "https://www.amazon.com/Under-Armour-Hustle-backpack-Graphite/dp/B01KLV3IMO/ref=sr_1_15?ie=UTF8&qid=1544615320&sr=8-15&keywords=mochilas+para+hombres+nike",
                        "", "S", 5,  "" ));
        imageMovieArrayList.add(
                new Backpack(10, "Heartly", "Marca:Nike", 2.0, 68, "https://www.amazon.com/NIKE-Heritage-Backpack-Black-Anthracite-x/dp/B078SRD5TX/ref=sr_1_18?ie=UTF8&qid=1544615320&sr=8-18&keywords=mochilas+para+hombres+nike",
                        "", "S", 10, ""));
  }
    public static ArrayList<Backpack> getImageMovieArrayList() {
        return imageMovieArrayList;
    }
}

