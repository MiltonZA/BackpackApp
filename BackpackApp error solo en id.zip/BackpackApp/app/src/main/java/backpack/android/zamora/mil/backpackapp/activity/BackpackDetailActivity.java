package backpack.android.zamora.mil.backpackapp.activity;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import backpack.android.zamora.mil.backpackapp.R;
import backpack.android.zamora.mil.backpackapp.entity.Backpack;
import backpack.android.zamora.mil.backpackapp.fragments.cars;
import butterknife.BindView;
import butterknife.ButterKnife;

public class BackpackDetailActivity extends AppCompatActivity {

    static Backpack backpack;
    @BindView(id.ivMovieBackdrop)
    ImageView ivMovieBackdrop;
    @BindView(id.tvOverview)
    TextView tvOverview;
    @BindView(id.imagenMochila)
    ImageView imagenMochila;

    Context context;
    cars carrritoC;
    static List<Backpack> listaCarrito = new ArrayList<Backpack>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mochila_detail);
        ButterKnife.bind(this);
        Toolbar toolbar = findViewById(id.toolbar);
        setSupportActionBar(toolbar);
        final FloatingActionButton fab = findViewById(id.fab);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle extras = getIntent().getExtras();

        //obtiene los datos del Inten
        obtenerDatos(extras);

        //Para que se cambien los iconos
        cambiarIcono(fab);

        fab.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(validaRepetido()){
                    listaCarrito.remove(backpack);
                    fab.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
                    fab.setImageResource(R.drawable.ic_add_black);
                    //fab.setBackgroundColor(123456);

                    Snackbar.make(view, "Juego retirado del carrito de compras", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }else{
                    listaCarrito.add(backpack);
                    fab.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorAccent)));
                    fab.setImageResource(R.drawable.ic_remove_black_24dp);
                    //fab.setBackgroundColor(123456);
                    Snackbar.make(view, "Juego agregado al carrito de compras", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }


            }


        });

    }

    public void cambiarIcono(FloatingActionButton fab){
        if(validaRepetido()){
            fab.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorAccent)));
            fab.setImageResource(R.drawable.ic_remove_black_24dp);
            //fab.setBackgroundColor((int)color.colorRojo);

        }else{
            fab.setBackgroundTintList(ColorStateList.valueOf(getResources().getColor(R.color.colorPrimary)));
            fab.setImageResource(R.drawable.ic_add_black);
            //fab.setBackgroundColor((int)color.colorAzul);


        }
    }
    //Obtener Datos
    public void obtenerDatos(Bundle extras){
        if (extras != null) {
            backpack = (Backpack) extras.getSerializable("MOVIE");
            this.setTitle(backpack.getTitle());
            tvOverview.setText(backpack.getShortdesc());
            ObtenerImagenes(context,imagenMochila,backpack.getUrl_image());
            ObtenerImagenes(context,ivMovieBackdrop,backpack.getUrl_imagen_poster());

        }
    }

    //valida producto repetido
    public boolean validaRepetido(){
        for(Backpack listaNew:getListaCarrito()){
            if(listaNew.getId()==(backpack.getId())){
                return true;
            }
        }
        return false;
    }

    //Obtine las imagenes
    public void ObtenerImagenes(Context contex,ImageView ivPoster,String recurso){
        if (recurso.isEmpty()) { //url.isEmpty()
            Picasso.with(context)
                    .load(R.drawable.notfount)
                    .placeholder(R.drawable.notfount)
                    .error(R.drawable.notfount)
                    .into(ivPoster);

        }else{
            Picasso.with(context)
                    .load(recurso)
                    .error(R.drawable.loading)
                    .placeholder(R.drawable.loading)
                    .into(ivPoster); //this is your ImageView
        }

    }
    //Obtenemos la lista Carrito
    public static List<Backpack> getListaCarrito() {
        return listaCarrito;
    }


    @Override
    public boolean onSupportNavigateUp(){
        finish();
        onPostResume();
        return true;
    }
}
