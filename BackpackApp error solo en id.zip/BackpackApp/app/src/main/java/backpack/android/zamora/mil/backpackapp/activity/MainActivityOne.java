package backpack.android.zamora.mil.backpackapp.activity;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import backpack.android.zamora.mil.backpackapp.MainActivity;
import backpack.android.zamora.mil.backpackapp.R;
import backpack.android.zamora.mil.backpackapp.models.BD;

public class MainActivityOne extends AppCompatActivity {
    CardView registrarse;
    CardView ir;

    BD helper = new BD(this,"DB1",null,1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_one);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        registrarse = (CardView) findViewById(R.id.view1);
        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registrarse = new Intent(MainActivityOne.this, Registro.class);
                startActivity(registrarse);
            }
        });
        ir = (CardView) findViewById(R.id.view);
        ir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText txtusu=(EditText)findViewById(R.id.ediUsuario);
                EditText txtPass = (EditText)findViewById(R.id.ediPassword);
                try {
                    Cursor cursor = helper.ConsultarUsuPas(txtusu.getText().
                            toString(),txtPass.getText().toString());
                    if(cursor.getCount()>0){
                        Intent ir = new Intent(MainActivityOne.this, MainActivity.class);
                        startActivity(ir);
                    }else{
                        Toast.makeText(getApplicationContext(),"USUARIO Y/O PASSWORD INCORRECTA.",
                                Toast.LENGTH_LONG).show();
                    }
                    txtusu.setText("");
                    txtPass.setText("");
                    txtusu.findFocus();
                }catch (SQLException e){
                    e.printStackTrace();
                }


            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}
