package backpack.android.zamora.mil.backpackapp.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import backpack.android.zamora.mil.backpackapp.R;
import backpack.android.zamora.mil.backpackapp.models.BD;

public class Registro extends AppCompatActivity {
    Button bt1;
    EditText txtNombre, txtEmail, txtContraseña;
    BD helper = new BD(this, "DB1", null, 1);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        bt1 = (Button) findViewById(R.id.btn1);
        txtNombre = (EditText) findViewById(R.id.nombre);
        txtEmail = (EditText) findViewById(R.id.email);
        txtContraseña = (EditText) findViewById(R.id.contraseña);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                helper.abrir();
                helper.insertarRegistro(String.valueOf(txtNombre.getText()),
                        String.valueOf(txtEmail.getText()),
                        String.valueOf(txtContraseña.getText()));
                helper.cerrar();

                Toast.makeText(getApplicationContext(), "SE HA REGISTRADO CON EXITO..!!", Toast.LENGTH_LONG).show();
                Intent i = new Intent(getApplicationContext(), MainActivityOne.class);
                startActivity(i);
            }
        });

    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return false;
    }
}
