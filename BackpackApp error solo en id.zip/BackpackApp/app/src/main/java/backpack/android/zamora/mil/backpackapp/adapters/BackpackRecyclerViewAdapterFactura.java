package backpack.android.zamora.mil.backpackapp.adapters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import backpack.android.zamora.mil.backpackapp.R;
import backpack.android.zamora.mil.backpackapp.entity.Backpack;
import butterknife.BindView;
import butterknife.ButterKnife;

public class BackpackRecyclerViewAdapterFactura extends RecyclerView.Adapter<BackpackRecyclerViewAdapterFactura.ViewHolder> {


    List<Backpack> backpacks;
    Context context;


    public BackpackRecyclerViewAdapterFactura(Context context, List<Backpack> movies){
        this.backpacks = movies;
        this.context = context;

    }

    private Context getContext(){
        return context;
    }

    @Override
    public BackpackRecyclerViewAdapterFactura.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_mochila_factura, parent, false);

        return new BackpackRecyclerViewAdapterFactura.ViewHolder(v);
    }



    @Override
    public void onBindViewHolder(BackpackRecyclerViewAdapterFactura.ViewHolder holder, int position) {

        Backpack backpack = backpacks.get(position);
        holder.txtTitulo.setText(backpack.getTitle());
        if(backpack.getOferta().contains("S")){
            //Normal
            holder.txtPrecio.setText(String.valueOf(backpack.getPrecioDescuento()));
            holder.txtPrecio.setTextColor(Color.parseColor("#ff0000"));
            //Tachado
            holder.textPrecioDescuento.setPaintFlags(holder.textPrecioDescuento.getPaintFlags()|Paint.STRIKE_THRU_TEXT_FLAG);

            //descuesto
            holder.textViewPrice_s2.setText("$");
            holder.textViewPrice_s2.setTextColor(Color.parseColor("#c0c0c0"));
            holder.textPrecioDescuento.setText(String.valueOf(backpack.getPrice()));
            holder.textPrecioDescuento.setTextColor(Color.parseColor("#c0c0c0"));
            //holder.txtPrecio.setTextColor(Color.parseColor("#ff0000"));

        }else{
            holder.txtPrecio.setText(String.valueOf(backpack.getPrice()));
        }

        ObtenerImagenes(backpack,holder);


    }



    //Obtener Imagenes
    public void ObtenerImagenes(Backpack backpack,BackpackRecyclerViewAdapterFactura.ViewHolder holder){
        if (backpack.getUrl_image().isEmpty()) { //url.isEmpty()
            Picasso.with(context)
                    .load(R.drawable.notfount)
                    .placeholder(R.drawable.notfount)
                    .error(R.drawable.notfount)
                    .into(holder.imPortada);
        }else{
            Picasso.with(context)
                    .load(backpack.getUrl_image())
                    .error(R.drawable.loading)
                    .placeholder(R.drawable.loading)
                    .into(holder.imPortada);
        }

    }


    @Override
    public int getItemCount() {
        return backpacks.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.ivImagenMochila)
        ImageView imPortada;
        @BindView(R.id.textNombreMochila)
        TextView txtTitulo;
        @BindView(R.id.textViewPrices)
        TextView txtPrecio;
        @BindView(R.id.cvBackpackFact)
        CardView cvFactura;
        @BindView(R.id.textPrecioDescuentos)
        TextView textPrecioDescuento;
        @BindView(R.id.textViewPrice_ss2)
        TextView textViewPrice_s2;

        ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);

        }

    }
}
