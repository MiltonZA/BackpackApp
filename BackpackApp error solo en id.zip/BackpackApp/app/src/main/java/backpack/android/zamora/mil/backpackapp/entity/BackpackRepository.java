package backpack.android.zamora.mil.backpackapp.entity;

import java.util.ArrayList;

public class BackpackRepository {

    Backpack backpack;

    public static ArrayList<Backpack> imageMovieArrayList= new ArrayList<Backpack>();


    public  BackpackRepository() {
        if(backpack==null){
            backpack=new Backpack();
        }

    }

    public Backpack getBackpack() {
        return backpack;
    }


    public static void initializeData() {
        imageMovieArrayList.removeAll(getImageMovieArrayList());
        imageMovieArrayList.add(
                new Backpack(1, "Elemental Sportwears", "Marca: Nike", 4.0, 45,  "https://www.amazon.com/Sportswear-Hayward-Futura-Backpack-Black-x/dp/B0163G9T1K/ref=sr_1_1?ie=UTF8&qid=1544593997&sr=8-1&keywords=mochilas+para+hombres+nike",
                        "", "N", 2, ""));

  }
    public static ArrayList<Backpack> getImageMovieArrayList() {
        return imageMovieArrayList;
    }
}

